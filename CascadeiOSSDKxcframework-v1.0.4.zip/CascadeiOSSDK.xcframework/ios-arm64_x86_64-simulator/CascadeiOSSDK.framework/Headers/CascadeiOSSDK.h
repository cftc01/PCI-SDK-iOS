//
//  CascadeiOSSDK.h
//  CascadeiOSSDK
//
//  Created by Matt Kuhn on 8/9/22.
//

#import <Foundation/Foundation.h>

//! Project version number for CascadeiOSSDK.
FOUNDATION_EXPORT double CascadeiOSSDKVersionNumber;

//! Project version string for CascadeiOSSDK.
FOUNDATION_EXPORT const unsigned char CascadeiOSSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <CascadeiOSSDK/PublicHeader.h>

